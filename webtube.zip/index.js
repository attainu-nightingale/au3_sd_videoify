var express=require('express');
var app=express();
var hbs = require('hbs');
app.set('view engine', 'hbs');
app.use(express.static('public'));
app.get('/',function(req,res){
    res.render('home.hbs',{
            title: 'Home',
            style: 'home.css',
    })
});

app.get('/home',function(req,res){
    res.send("HOME")
});

app.get('/profile',function(req,res){
    res.send("PROFILE")
});

app.get('/trending',function(req,res){
    res.send("TRENDING")
});

app.get('/video/:id',function(req,res){
    res.send("INDIVIDUAL VIDEO PAGE")
});

app.listen(3000);